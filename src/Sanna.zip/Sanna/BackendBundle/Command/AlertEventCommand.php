<?php

namespace Sanna\BackendBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class AlertEventCommand  extends ContainerAwareCommand
{

    protected function configure(){
        $this->setName('sanna:alertevent')
            ->setDescription('descripción de lo que hace el comando')
            ->addArgument('my_argument', InputArgument::OPTIONAL, 'Explicamos el significado del argumento');
    }
    protected function execute(InputInterface $input, OutputInterface $output){
        $em = $this->getContainer()->get('doctrine')->getManager();
        $events = $em->getRepository('UsuarioBundle:Event')->findAll();
        //$timeActual= time();
        $timeActual= time();   // Obtenemos el timestamp del momento actual
        //$timeVencimiento = strtotime($events[0]->getEnd()->getTimestamp()); // Obtenemos timestamp de la fecha de vencimiento
        $timeVencimiento = $events[0]->getEnd()->getTimestamp(); // Obtenemos timestamp de la fecha de vencimiento

            // Calculamos el número de segundos que tienen esos 3 días
        $segundos = 3 * 24 * 60 * 60;

        // Condición: Si la diferencia entre la fecha de vencimiento y la fecha actual es menor de 3 días
        if( $timeVencimiento-$timeActual < $segundos) {
            $output->writeln('Holaaaa');
        }else{
            $output->writeln('AKI siiii');
        }
       // $em->flush();

    }
    function calculaFecha($modo,$valor,$fecha_inicio=false){

        if($fecha_inicio!=false) {
            $fecha_base = strtotime($fecha_inicio);
        }else {
            $time=time();
            $fecha_actual=date("Y-m-d",$time);
            $fecha_base=strtotime($fecha_actual);
        }

        $calculo = strtotime("$valor $modo","$fecha_base");

        return date("Y-m-d", $calculo);

    }

} 