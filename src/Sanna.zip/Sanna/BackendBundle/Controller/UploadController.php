<?php

namespace Sanna\BackendBundle\Controller;

use Sanna\BackendBundle\Entity\File;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\UserComponent\UserComponent;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Email\EmailComponent;

class UploadController extends Controller
{
    var $user_comp;

    public function __construct(){
        $this->user_comp = new UserComponent($this);
    }
	
	 public function getNameFolder(){
        $em = $this->get('doctrine')->getManager();
        $files = $em->getRepository('BackendBundle:File')->findAll();
        $data = array();
        foreach($files as $item){
            $data[] = array(
                'id'=>$item->getId(),
                'name_folder'=>$item->getNameFolder()
            );
        }
        return $data;
    }


    public function  uploadAction(){
        $user = $this->get('security.context')->getToken()->getUser();
        $id = $user->getId();
        $data['user'] = $this->user_comp->getInformationInfo($id);
        $userfiles = $result_keys = array();
        if(!empty($_POST)){
            //echo '<pre>';print_r($_POST);die;
			 $em = $this->get('doctrine')->getManager();
            //si es un nuevo folder
            if($_POST['new']==0){
                $namefolder = $_POST['namefolder'];
            }elseif($_POST['new']==1){
                $namefolder = $_POST['oldfolder'];
            }
            //get Name User          
            $users = explode(',', $_POST['users']);
            //print_r($users); die;
            $file = new File();
            $file->setFile($_POST['namefile'].'.'.$this->extension($_FILES['file']['name']));
            $file->setNameFolder($_POST['namefolder']);
            $dir = $_SERVER["DOCUMENT_ROOT"].'/web/upload/files/';
            foreach ($users as $key => $value) {
                $user = $em->getRepository('UsuarioBundle:User')->find($value);
                $profile = $em->getRepository('UsuarioBundle:Profile')->findOneBy(array('user'=>$user->getId()));
                $this->uploadFile($profile->getName(),$_POST['namefile'], $_FILES, $dir);
                //save DB
                $file->addUser($user);
            }
            $tmp = $_POST['namefile'].'.'.$this->extension($_FILES['file']['name']);
            $this->delTemp($dir.'/'.$tmp);

            $em->persist($file);
            $em->flush();

            $path = $dir.$profile->getName();
            $subject = 'Document!!!';
            $email_user = $user->getEmail();
            $msg = "Ciaoo!!";
            $dir = $path.'/'.$tmp;

            //send email
            $email = \Swift_Message::newInstance()
                ->setSubject("".$subject."")
                ->setFrom("test@studiopierpaolosanna.it")
                ->setTo("".$email_user."")
                ->setBody(
                    $this->renderView(
                        'BackendBundle:Email:email_template.html.twig',
                        array('data_client'=>$msg)
                    ),
                    'text/html'
                )
                ->attach(\Swift_Attachment::fromPath(''.$dir.'')
                );
                if($this->get('mailer')->send($email)){
                    $response = array("code" => 1, 'message'=>'Document uploaded successfully!!!');
                    return new Response(json_encode($response));
                }
        }else{
            $jsonencoder = new JsonEncoder();
            $array_userfiles = $this->getAllFilesUser();
            if(!empty($array_userfiles)){
                $userfiles = $jsonencoder->encode($array_userfiles,$format = 'json');
                foreach($array_userfiles as $val=>$key){
                    $array_keys[] = array_keys($key);
                }
                $data['userfiles'] = $userfiles;
                $result_keys = $jsonencoder->encode($array_keys,$format = 'json');
                $data['keys'] = $result_keys;
            }else{
                $data['userfiles'] = $userfiles;
                $data['keys'] = $result_keys;
            }
                // echo '<pre>';print_r($userfiles);die;
            echo $this->getAllFolderUser();
            $data['profiles'] = $this->user_comp->getAllUser();
			$folders = $this->getNameFolder();
            if(!empty($folders)){
                $data['folder'] = $this->getNameFolder();
            }
            return $this->render('BackendBundle:Default:upload_file.html.twig', array('result'=>array('data'=>$data)));
        }
    }

    function uploadFile($name, $namefile, $file = array(), $dir){
        $allowedExtensions = array('docx','doc','pdf','xlsx');
        $flag = (in_array($this->extension($file['file']['name']),$allowedExtensions))?true:false;
        if($flag){
            $path = $dir.'/'.$name;
            if (!file_exists($path)) {
               mkdir($path, 0777, true);
            }
            if(move_uploaded_file($file['file']['tmp_name'], $dir.'/'.$namefile.'.'.$this->extension($file['file']['name']))){
                copy( $dir.'/'.$namefile.'.'.$this->extension($file['file']['name']) , $path.'/'.$namefile.'.'.$this->extension($file['file']['name']));
                sleep(3);
            }
            else copy( $dir.'/'.$namefile.'.'.$this->extension($file['file']['name']) , $path.'/'.$namefile.'.'.$this->extension($file['file']['name']));
        }
        $file = $path.''.$file['file']['name'];
        return $file;
    }

    function delTemp($file_temp){
        unlink($file_temp);
    }

    function extension($filename){
        return substr(strrchr($filename, '.'), 1);
    }

    public function getAllFolderUser(){
        $em = $this->get('doctrine')->getManager();
        $files = $em->getRepository('BackendBundle:File')->findAll();



       // echo '<pre>';print_r($files);die;
    }

    //get all files x user
    public function getAllFilesUser(){
        $em = $this->get('doctrine')->getManager();
        $result = $users_arr = $arra_folder = array();
        if ($this->get('security.context')->isGranted('ROLE_ADMIN')){
            $files = $em->getRepository('BackendBundle:File')->findAll();
            foreach ($files as $key => $value) {
                $users = $value->getUsers();
                foreach ($users as $k => $v) {
                    $iduser = $v->getId();
                    $profile = $em->getRepository('UsuarioBundle:Profile')->findOneBy(array('user'=>$iduser));
                    $name = $profile->getName().' '.$profile->getLastName();
                    $folder = $value->getNameFolder();
                    if (in_array($iduser, $users_arr)){
                        $pos = array_search($iduser, $users_arr);
                        if(in_array($folder,$arra_folder)){
                            $result[$pos][$name][$folder][] = array(
                                'id'=>$value->getid(),
                                'file'=>$value->getFile()
                            );
                        }else{
                            $result[$pos][$name][$folder][] = array(
                                'id'=>$value->getid(),
                                'file'=>$value->getFile()
                            );
                            $arra_folder[] = $folder;
                        }
                    }
                    else{
                        unset($data);
                        $data[$name][$folder][] = array(
                            'id'=>$value->getid(),
                            'file'=>$value->getFile()
                        );
                        $result[] = $data;
                        $users_arr[] = $iduser;
                    }
                }
            }
        }else{
            //echo 'If 2';
            $user = $this->get('security.context')->getToken()->getUser();
            $iduser = $user->getId();
           // echo $iduser;die;
            $files = $em->getRepository('BackendBundle:File')->findAll();
            // echo '<pre>';print_r($files);die;
            //$files = $em->getRepository('BackendBundle:File')->findBy(array('users'=>$iduser));
            $profile = $em->getRepository('UsuarioBundle:Profile')->findOneBy(array('user'=>$iduser));
           // echo '<pre>';print_r($files);die;
            $name = $profile->getName().' '.$profile->getLastName();
            foreach($files as $file){
                $folder = $file->getNameFolder();
                $users = $file->getUsers();
                foreach($users as $item){
                    if($item->getId()== $iduser){
                        if(in_array($folder,$arra_folder)){
                            $data[$name][$folder][] = array(
                                'id'=>$file->getid(),
                                'file'=>$file->getFile()
                            );
                        }else{
                            $data[$name][$folder][] = array(
                                'id'=>$file->getid(),
                                'file'=>$file->getFile()
                            );
                            $arra_folder[] = $folder;
                        }

                        array_push($result,$data);
                    }
                }

            }
        }

       // echo '<pre>';print_r($result);die;

        return $result;
    }

    public function fileAction(){
        $user = $this->get('security.context')->getToken()->getUser();
        $id = $user->getId();
        $data['user'] = $this->user_comp->getInformationInfo($id);
        $userfiles = $result_keys = array();

       // $files = $this->getAllFilesUser();

        $jsonencoder = new JsonEncoder();
        $array_userfiles = $this->getAllFilesUser();
        $data['files'] = $array_userfiles;
        if(!empty($array_userfiles)){
            $userfiles = $jsonencoder->encode($array_userfiles,$format = 'json');
            foreach($array_userfiles as $val=>$key){
                $array_keys[] = array_keys($key);
            }
            $data['userfiles'] = $userfiles;
            $result_keys = $jsonencoder->encode($array_keys,$format = 'json');
            $data['keys'] = $result_keys;
        }else{
            $data['userfiles'] = $userfiles;
            $data['keys'] = $result_keys;
        }

        //echo '<pre>';print_r($data);die;

        return $this->render('BackendBundle:Default:file.html.twig', array('result'=>array('data'=>$data)));
    }
}