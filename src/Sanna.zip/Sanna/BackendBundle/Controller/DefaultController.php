<?php

namespace Sanna\BackendBundle\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\UserComponent\UserComponent;


class DefaultController extends Controller
{

    var $user_comp;

    public function __construct()
    {
        $this->user_comp = new UserComponent($this);
    }

    public function indexAction()
    {
        $user = $this->get('security.context')->getToken()->getUser();
        $id = $user->getId();

        $em = $this->getDoctrine()->getManager();
        //$events = $em->getRepository('UsuarioBundle:Event')->findAll();

        $data['events'] = $this->user_comp->showNotificacion($id);

        //get personal info
        $data['user'] =  $this->user_comp->getInformationInfo($id);

       return $this->render('BackendBundle:Default:index.html.twig', array('result'=>array('data'=>$data)));
    }




}
